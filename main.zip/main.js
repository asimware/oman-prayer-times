const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage } = require("electron");
const https = require("https");
const path = require("path");
const { decodeHTML } = require("entities");

const PRAYER_URL = "https://www.mara.gov.om/arabic/calendar_page3.asp";
const APP_ICON_PATH = path.join(__dirname, "pray.png");

let mainWindow = null;
let tray = null;
let isQuitting = false;
const gotSingleInstanceLock = app.requestSingleInstanceLock();

if (!gotSingleInstanceLock) {
  app.quit();
  // Ensure the second instance exits immediately (prevents brief flashes on Windows startup).
  process.exit(0);
}

function extractCityRows(html) {
  const rows = [...html.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)];
  const cityData = [];

  for (let i = 0; i < rows.length; i += 1) {
    const rowHtml = rows[i][1];
    const cells = [...rowHtml.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)].map((m) =>
      decodeHTML(m[1].replace(/<[^>]*>/g, "").trim())
    );

    if (cells.length < 7) {
      continue;
    }

    cityData.push({
      cityArabic: cells[0],
      fajr: cells[1],
      sunrise: cells[2],
      dhuhr: cells[3],
      asr: cells[4],
      maghrib: cells[5],
      isha: cells[6],
    });
  }

  if (cityData.length === 0) {
    throw new Error("Could not parse city rows from source HTML.");
  }

  return cityData;
}

async function fetchPrayerTimesForDate(year, month, day) {
  const body = new URLSearchParams({
    year: String(year),
    month: String(month),
    day: String(day),
    B1: "أعرض",
  }).toString();

  const url = new URL(PRAYER_URL);
  const html = await new Promise((resolve, reject) => {
    const request = https.request(
      {
        protocol: url.protocol,
        hostname: url.hostname,
        port: url.port || 443,
        path: `${url.pathname}${url.search}`,
        method: "POST",
        // Requested by user: scrape without validating TLS cert.
        rejectUnauthorized: false,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Content-Length": Buffer.byteLength(body),
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
          Origin: "https://www.mara.gov.om",
          Referer: PRAYER_URL,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        },
      },
      (response) => {
        let data = "";
        response.setEncoding("utf8");
        response.on("data", (chunk) => {
          data += chunk;
        });
        response.on("end", () => {
          if ((response.statusCode || 500) >= 400) {
            reject(new Error(`Source request failed with status ${response.statusCode}`));
            return;
          }
          resolve(data);
        });
      }
    );

    request.on("error", (error) => reject(error));
    request.write(body);
    request.end();
  });

  if (!html || html.length < 500) {
    throw new Error("Source returned an empty or unexpected response.");
  }
  return extractCityRows(html);
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1040,
    height: 760,
    minWidth: 900,
    minHeight: 640,
    backgroundColor: "#0B1220",
    icon: APP_ICON_PATH,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile("index.html");

  mainWindow.on("minimize", (event) => {
    event.preventDefault();
    mainWindow.hide();
  });

  mainWindow.on("close", (event) => {
    if (!isQuitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });
}

function showMainWindow() {
  if (!mainWindow) {
    return;
  }

  mainWindow.show();
  if (mainWindow.isMinimized()) {
    mainWindow.restore();
  }
  mainWindow.focus();
}

function createTray() {
  if (tray) {
    return;
  }

  const icon = nativeImage.createFromPath(APP_ICON_PATH).resize({
    width: 16,
    height: 16,
  });

  tray = new Tray(icon);
  tray.setToolTip("Prayer Times Oman");
  tray.setContextMenu(
    Menu.buildFromTemplate([
      {
        label: "Show App",
        click: () => showMainWindow(),
      },
      {
        label: "Quit",
        click: () => {
          isQuitting = true;
          app.quit();
        },
      },
    ])
  );
  tray.on("double-click", () => showMainWindow());
}

ipcMain.handle("prayer-times:scrape", async (_event, payload) => {
  const { year, month, day } = payload || {};

  if (!year || !month || !day) {
    throw new Error("Missing date parameters.");
  }

  try {
    const cities = await fetchPrayerTimesForDate(year, month, day);
    return {
      source: PRAYER_URL,
      date: { year, month, day },
      cities,
    };
  } catch (error) {
    throw new Error(`Scrape failed: ${error.message}`);
  }
});

app.whenReady().then(() => {
  // Only configure auto-start for packaged apps.
  // In dev mode, enabling this can register `electron.exe` as a startup item,
  // which shows an extra "electron" popup/console on Windows boot.
  if (app.isPackaged) {
    app.setLoginItemSettings({
      openAtLogin: true,
      openAsHidden: false,
    });
  }

  createWindow();
  createTray();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0 || !mainWindow) {
      createWindow();
      return;
    }

    showMainWindow();
  });
});

app.on("second-instance", () => {
  showMainWindow();
});

app.on("window-all-closed", () => {
  // Keep app running in tray; quit via tray menu.
});
