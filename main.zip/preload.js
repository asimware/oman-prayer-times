const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("prayerScraper", {
  scrapePrayerTimes: (datePayload) => ipcRenderer.invoke("prayer-times:scrape", datePayload),
});
