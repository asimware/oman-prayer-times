const citySelect = document.getElementById("citySelect");
const timesBody = document.getElementById("timesBody");
const statusText = document.getElementById("statusText");
const statusSubtext = document.getElementById("statusSubtext");
const systemDate = document.getElementById("systemDate");
const systemTime = document.getElementById("systemTime");
const audioLabel = document.getElementById("audioLabel");
const refreshBtn = document.getElementById("refreshBtn");
const changeAudioBtn = document.getElementById("changeAudioBtn");
const stopAudioBtn = document.getElementById("stopAudioBtn");
const audioFileInput = document.getElementById("audioFileInput");

const prayerOrder = ["fajr", "dhuhr", "asr", "maghrib", "isha"];
const prayerNames = {
  fajr: "الفجر",
  sunrise: "الشروق",
  dhuhr: "الظهر",
  asr: "العصر",
  maghrib: "المغرب",
  isha: "العشاء",
};

const cityNames = {
  "مسقط": "Muscat",
  "صلالة": "Salalah",
  "عبري": "Ibri",
  "نزوى": "Nizwa",
  "البريمي": "Al Buraimi",
  "صحار": "Sohar",
  "الرستاق": "Rustaq",
  "صور": "Sur",
  "ابراء": "Ibra",
  "هيما": "Haima",
};

let dateCacheKey = "";
let allCities = [];
let selectedCityArabic = "مسقط";
let lastTriggeredPrayerKey = "";
let selectedCityData = null;
let customAudioUrl = "";
const defaultAudioPath = "./adhan.mp3";
const alarmAudio = new Audio(defaultAudioPath);
alarmAudio.loop = false;
const hasElectronBridge =
  typeof window !== "undefined" &&
  window.prayerScraper &&
  typeof window.prayerScraper.scrapePrayerTimes === "function";

function formatSystemDateLabel(dateObj) {
  const weekdayArabic = new Intl.DateTimeFormat("ar", {
    weekday: "long",
    numberingSystem: "latn",
  }).format(dateObj);

  const dd = String(dateObj.getDate()).padStart(2, "0");
  const mm = String(dateObj.getMonth() + 1).padStart(2, "0");
  const yyyy = String(dateObj.getFullYear());

  return `${weekdayArabic} ${dd}/${mm}/${yyyy}`;
}

function formatSystemTimeLabel(dateObj) {
  return dateObj.toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
}

function renderFixedWidthTime(targetEl, timeText) {
  if (!targetEl) {
    return;
  }

  const safeText = String(timeText || "");
  targetEl.innerHTML = safeText
    .split("")
    .map((ch) => {
      if (ch === " ") {
        return '<span class="time-char time-space">&nbsp;</span>';
      }
      return `<span class="time-char">${ch}</span>`;
    })
    .join("");
}

function setStatus(mainText, subText = "") {
  if (statusText) {
    statusText.textContent = mainText;
  }
  if (statusSubtext) {
    statusSubtext.textContent = subText;
  }
}

function parseTimeToMinutes(timeText) {
  const [h, m] = timeText.split(":").map((n) => Number(n));
  if (Number.isNaN(h) || Number.isNaN(m)) {
    return null;
  }
  return h * 60 + m;
}

function to24HourMinutes(prayerName, timeText) {
  const parsed = parseTimeToMinutes(timeText);
  if (parsed === null) {
    return null;
  }

  const hour = Math.floor(parsed / 60);
  const minute = parsed % 60;

  // Ministry page provides most prayer times in 12-hour format without AM/PM.
  // Fajr and Sunrise are AM; Dhuhr/Asr/Maghrib/Isha are PM.
  if (prayerName === "fajr" || prayerName === "sunrise") {
    return hour * 60 + minute;
  }

  // Requested rule: if Dhuhr appears between 10:00 and 11:59, keep it AM.
  if (prayerName === "dhuhr" && hour >= 10 && hour <= 11) {
    return hour * 60 + minute;
  }

  if (hour === 12) {
    return 12 * 60 + minute;
  }

  return (hour + 12) * 60 + minute;
}

function formatPrayerTimeDisplay(prayerName, timeText) {
  if (!timeText || timeText === "--:--") {
    return "--:--";
  }

  const parsed = parseTimeToMinutes(timeText);
  const hour = parsed === null ? null : Math.floor(parsed / 60);
  const isAmPrayer =
    prayerName === "fajr" ||
    prayerName === "sunrise" ||
    (prayerName === "dhuhr" && hour !== null && hour >= 10 && hour <= 11);
  const suffix = isAmPrayer ? "ص" : "م";
  return `${timeText} ${suffix}`;
}

function getNowDateParts() {
  const now = new Date();
  return {
    year: now.getFullYear(),
    month: now.getMonth() + 1,
    day: now.getDate(),
    key: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`,
    now,
  };
}

function cityLabel(cityArabic) {
  return cityNames[cityArabic] ? `${cityArabic} (${cityNames[cityArabic]})` : cityArabic;
}

function updateStatusByTime() {
  if (!selectedCityData) {
    return;
  }

  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  let nextPrayer = null;

  for (const prayer of prayerOrder) {
    const minutes = to24HourMinutes(prayer, selectedCityData[prayer]);
    if (minutes !== null && nowMinutes < minutes) {
      nextPrayer = { prayer, minutes };
      break;
    }
  }

  if (nextPrayer) {
    const minutesLeft = nextPrayer.minutes - nowMinutes;
    setStatus(
      `الصلاة القادمة: ${prayerNames[nextPrayer.prayer]} ${formatPrayerTimeDisplay(nextPrayer.prayer, selectedCityData[nextPrayer.prayer])}`,
      `متبقي: ${minutesLeft} دقيقة`
    );
  } else {
    setStatus("انتهت جميع مواقيت الصلاة لليوم.", "");
  }
}

function renderTimes() {
  if (!selectedCityData) {
    timesBody.innerHTML = "";
    return;
  }

  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const prayers = Object.keys(prayerNames);

  const prayerHeaderCells = prayers
    .map((prayer) => `<th>${prayerNames[prayer]}</th>`)
    .join("");

  const timeCells = prayers
    .map((prayer) => {
      const timeVal = selectedCityData[prayer] || "--:--";
      const minutesForPrayer = to24HourMinutes(prayer, timeVal);
      const activeClass = minutesForPrayer !== null && minutesForPrayer === nowMinutes ? "active-cell" : "";
      return `<td class="${activeClass}">${formatPrayerTimeDisplay(prayer, timeVal)}</td>`;
    })
    .join("");

  timesBody.innerHTML = `
    <tr>
      ${prayerHeaderCells}
    </tr>
    <tr>
      ${timeCells}
    </tr>
  `;
}

function updateSystemTime() {
  const now = new Date();
  if (systemDate) {
    systemDate.textContent = formatSystemDateLabel(now);
  }
  if (systemTime) {
    renderFixedWidthTime(systemTime, formatSystemTimeLabel(now));
  }
}

function fillCityDropdown() {
  citySelect.innerHTML = allCities
    .map((city) => {
      const selectedAttr = city.cityArabic === selectedCityArabic ? "selected" : "";
      return `<option value="${city.cityArabic}" ${selectedAttr}>${cityLabel(city.cityArabic)}</option>`;
    })
    .join("");
}

function setSelectedCity(cityArabic) {
  selectedCityArabic = cityArabic;
  selectedCityData = allCities.find((c) => c.cityArabic === cityArabic) || null;
  renderTimes();
  updateStatusByTime();
}

async function loadPrayerTimesForToday(forceReload = false) {
  if (!hasElectronBridge) {
    throw new Error("يرجى تشغيل التطبيق عبر Electron باستخدام npm start");
  }

  const dateParts = getNowDateParts();
  const dateChanged = dateCacheKey !== dateParts.key;
  if (!forceReload && !dateChanged && allCities.length > 0) {
    return;
  }

  const payload = {
    year: dateParts.year,
    month: dateParts.month,
    day: dateParts.day,
  };

  setStatus("جاري تحميل مواقيت الصلاة...", "يرجى الانتظار...");
  updateSystemTime();

  const data = await window.prayerScraper.scrapePrayerTimes(payload);
  allCities = data.cities;
  dateCacheKey = dateParts.key;
  lastTriggeredPrayerKey = "";

  if (!allCities.some((c) => c.cityArabic === selectedCityArabic)) {
    selectedCityArabic = allCities[0]?.cityArabic || "";
  }

  fillCityDropdown();
  setSelectedCity(selectedCityArabic);
}

function stopAudio() {
  alarmAudio.pause();
  alarmAudio.currentTime = 0;
}

function triggerPrayerIfNeeded() {
  if (!selectedCityData) {
    return;
  }

  const now = new Date();
  const current = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const dateKey = getNowDateParts().key;

  for (const prayer of prayerOrder) {
    const prayerTime = selectedCityData[prayer];
    const prayerMinutes = to24HourMinutes(prayer, prayerTime);
    if (prayerMinutes === currentMinutes) {
      const uniqueKey = `${dateKey}-${selectedCityArabic}-${prayer}`;
      if (lastTriggeredPrayerKey !== uniqueKey) {
        lastTriggeredPrayerKey = uniqueKey;
        alarmAudio.currentTime = 0;
        alarmAudio.play().catch(() => {
          setStatus("حان وقت الصلاة.", "اضغط داخل التطبيق لتفعيل تشغيل الصوت.");
        });
      }
      break;
    }
  }
}

function setAudioFile(file) {
  if (!file) {
    return;
  }

  if (customAudioUrl) {
    URL.revokeObjectURL(customAudioUrl);
  }

  customAudioUrl = URL.createObjectURL(file);
  alarmAudio.src = customAudioUrl;
  audioLabel.textContent = `صوت مخصص: ${file.name}`;
}

citySelect.addEventListener("change", (e) => {
  setSelectedCity(e.target.value);
});

refreshBtn.addEventListener("click", async () => {
  try {
    await loadPrayerTimesForToday(true);
  } catch (error) {
    setStatus(`فشل التحديث: ${error.message}`, "");
  }
});

changeAudioBtn.addEventListener("click", () => {
  audioFileInput.click();
});

audioFileInput.addEventListener("change", (e) => {
  const file = e.target.files?.[0];
  setAudioFile(file);
});

stopAudioBtn.addEventListener("click", () => {
  stopAudio();
});

const REFRESH_INTERVAL_MS = 60 * 1000;

if (hasElectronBridge) {
  updateSystemTime();
  setInterval(updateSystemTime, 1000);
  setInterval(async () => {
    try {
      await loadPrayerTimesForToday(false);
      renderTimes();
      updateStatusByTime();
      triggerPrayerIfNeeded();
    } catch (error) {
      setStatus(`تعذر تحديث المواقيت: ${error.message}`, "");
    }
  }, REFRESH_INTERVAL_MS);
} else {
  setStatus("شغّل التطبيق عبر Electron (npm start) لتحميل المواقيت.", "");
  updateSystemTime();
  setInterval(updateSystemTime, 1000);
}

window.addEventListener("beforeunload", () => {
  if (customAudioUrl) {
    URL.revokeObjectURL(customAudioUrl);
  }
});

(async function init() {
  try {
    await loadPrayerTimesForToday(true);
    audioLabel.textContent = "يتم استخدام الصوت الافتراضي";
  } catch (error) {
    setStatus(`فشل تحميل مواقيت الصلاة: ${error.message}`, "");
  }
})();
